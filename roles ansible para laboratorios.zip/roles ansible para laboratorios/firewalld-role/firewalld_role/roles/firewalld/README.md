Role Name
=========

Este role lo que hace es aplicar reglas al firewall, utilizando firewall-cmd

Requirements
------------

El unico requerimiento es que sapan lo que estan haciendo.

Role Variables
--------------

Deben de declarar los servicios y puestos en el lugar correcto, tambien lo pueden definir en otros lugares. Pero recuerde utilizar la sintaxis correcta. (roles/firewalld/defaults/main.yml)

Dependencies
------------

No creo que exista alguna dependencia

Example Playbook
----------------

Ejemplo 1:
---
- hosts: grupo1
  become: "{{ use_sudo|default(True) }}"
  roles:
    - firewalld
 
...

Ejemplo 2:
---
- hosts: grupo1
  become: "{{ use_sudo|default(True) }}"
  vars:
    firewalld_allow_services:
      - { service: "http" }
      - { service: "smb", zone: "dmz", permanent: "True", immediate: "True" }
  roles:
    - firewalld
 
...


Verificando firewall en el node
------------------------------

firewall-cmd --list-all
public (active)
  target: default
  icmp-block-inversion: no
  interfaces: eth0
  sources: 
  services: ssh dhcpv6-client http
  ports: 12345/tcp
  protocols: 
  masquerade: no
  forward-ports: 
  source-ports: 
  icmp-blocks: 
  rich rules: 
	
firewall-cmd --list-all --zone dmz
dmz
  target: default
  icmp-block-inversion: no
  interfaces: 
  sources: 
  services: ssh samba
  ports: 
  protocols: 
  masquerade: no
  forward-ports: 
  source-ports: 
  icmp-blocks: 
  rich rules: 
	
License
-------

BSD

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).


