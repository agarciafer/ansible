#!/bin/bash
sudo yum clean all
#yum update -y
sudo yum install epel-release -y
sudo yum install -y ansible 
systemctl stop firewalld
systemctl disable firewalld
sed -i 's/^SELINUX=.*/SELINUX=disabled/g' /etc/selinux/config
#ssh-copy-id root@192.168.33.11
cp  /vagrant/provision/inventario/hosts /etc/ansible
cp  /vagrant/provision/ansible.cfg /etc/ansible
mkdir -p /root/.ssh
cp  /vagrant/provision/id*  /root/.ssh
chmod 600 /root/.ssh/id_rsa
cp -r /vagrant/provision/playbook-resueltos  /etc/ansible
cp -r /vagrant/provision/group_vars  /etc/ansible
cp -r /vagrant/provision/host_vars  /etc/ansible
cp -r /vagrant/provision/tasks  /etc/ansible
cp -r /vagrant/provision/templates  /etc/ansible
cp -r /vagrant/provision/vars  /etc/ansible
cp  /vagrant/provision/hosts /etc/
#ansible servidores  -m ping