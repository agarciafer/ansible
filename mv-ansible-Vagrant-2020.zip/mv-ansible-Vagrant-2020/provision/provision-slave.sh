#!/bin/bash
#ssh-copy-id root@192.168.33.11
systemctl stop firewalld
systemctl disable firewalld
sed -i 's/^SELINUX=.*/SELINUX=disabled/g' /etc/selinux/config
mkdir -p /root/.ssh
cp  /vagrant/provision/authorized_keys  /root/.ssh
cp  /vagrant/provision/sudoers /etc
cp  /vagrant/provision/hosts /etc/

